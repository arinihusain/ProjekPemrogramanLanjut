package project;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class koneksiDB_1 {
    public static Connection koneksi=konek();
    public static Connection konek(){
        try{
            return DriverManager.getConnection("jdbc:mysql://localhost/projek","root","");
        }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e);
           return null;
        }
     }
    
//    Table User
    public static void insertUser(String username, String password, String lvl){
        String query = "INSERT INTO user VALUES ('"+username+"','"+password+"','"+lvl+"')";
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    
    public static String admin(String username, String password){
        String query = "SELECT * FROM user WHERE username='"+username+"' AND password ='"+password+"'";
        try{
            Statement stmt = koneksi.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next()){
                return rs.getString("lvl");
            }
            return null;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null, e);
      }
      return null;
    }
    
//     Tabel Menu
    public static void readMenu(DefaultTableModel model){
        String query = "SELECT * FROM menu";
        try{
            Statement stmt = koneksi.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                Object[] data = {
                    rs.getString("kode_menu"),
                    rs.getString("nama_menu"),
                    rs.getString("harga")
                };
                model.addRow(data);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public static void insertMenu(String kode, String nama, int harga){
        String query = "INSERT INTO menu VALUES ('"+kode+"','"+nama+"',"+harga+")";
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    public static void updateMenu(String kode_menu, int harga){
        String query = "UPDATE menu SET harga = "+harga+" WHERE kode_menu = '"+kode_menu+"'";
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    public static void deleteMenu(String kode_menu){
        String query = "DELETE FROM menu WHERE kode_menu = '"+kode_menu+"'";
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
//     Tabel Pelanggan
    public static void insertPelanggan(String nama){
        String query = "INSERT INTO pelanggan (nama_pelanggan) VALUES ('"+nama+"')";
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    public static boolean cekPelanggan(String nama){
        String query = "SELECT * FROM pelanggan WHERE nama_pelanggan='" + nama + "'";
        try{
            Statement stmt = koneksi.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next()){
                return true;
            }
            return false;
      }catch(SQLException e){
          JOptionPane.showMessageDialog(null, e);
      }
      return false;
    }
    
//     Tabel Transaksi
    public static void insertTransaksi(int id_trx){
        String query = "INSERT INTO transaksi (id_pemesanan) VALUES ("+id_trx+")";
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    public static void updatePemesanan(int id_pemesanan){
        String query = "UPDATE pemesanan SET status = 'paid' WHERE id_pemesanan = "+id_pemesanan;
        try{
            Statement stmt = koneksi.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    
//     Tabel Pemesanan
    public static void insertPemesanan(String nama, String kode_men, int jumlah){
        if (cekPelanggan(nama)){ 
            String query = "INSERT INTO pemesanan (nama_pelanggan,kode_menu, jumlah) VALUES ('"+nama+"','"+kode_men+"',"+jumlah+")";
            try{
                Statement stmt = koneksi.createStatement();
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.out.println(e);
            }
        } else {
            insertPelanggan(nama);
            insertPemesanan(nama, kode_men, jumlah);
        }
    }


    
    public static void LodaTable(DefaultTableModel model, javax.swing.JFrame induk){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        try {
            String query = "SELECT * FROM pemesanan";
            Statement st = koneksi.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()){
                Object[] data = {
                    rs.getString("id_pemesanan"),
                    rs.getString("nama_pelanggan"),
                    rs.getString("kode_menu"),
                    rs.getString("jumlah"),
                };
                model.addRow(data);
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(induk, e);
        }
    }
    
    
    public static void LodaTableTr(DefaultTableModel model, javax.swing.JFrame induk){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        try {
            String query = "select pemesanan.id_pemesanan, pemesanan.nama_pelanggan, menu.nama_menu, pemesanan.jumlah, menu.harga, pemesanan.status from pemesanan, menu where pemesanan.kode_menu = menu.kode_menu;";
            Statement st = koneksi.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()){
                Object[] data = {
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                };
                model.addRow(data);
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(induk, e);
        }
    }
    
    
    public static void main(String args[]){

    }
}
